# Experiment design and decision contract

## Business question

Among eligible drivers, does an incentive increase next-week trips enough to justify the campaign cost, and can a predictive ranking improve whom we test next?

## Primary estimand

The intent-to-treat average treatment effect on `trips_next_week`:

`ATE = mean(trips_next_week | treatment=1) - mean(trips_next_week | treatment=0)`

Eligibility and assignment must be defined before exposure; analyze drivers by assigned arm, not by whether they redeemed or complied. Use Welch's two-sample interval/test as a transparent default. For real launch decisions, account for repeated drivers across campaigns, marketplace interference, clustering by geography/time, and pre-specified guardrails.

## Outcome hierarchy

- Primary: trips next week.
- Secondary: online hours and active-driver rate.
- Financial: incentive cost and scenario ROI. Cost is a descriptive delivery metric; it is not treated as an outcome in the efficacy test.
- Guardrails recommended for real execution: cancellation rate, acceptance rate, service level / ETA, driver earnings, passenger price, and spillover to untreated drivers.

## Assignment and sample

The generator creates 12,000 synthetic driver records and assigns exactly 5,899 to treatment and 6,101 to control using a randomized shuffle. This count split preserves the earlier demo's scale; it is not a recommended production allocation. Production power analysis should use baseline variance, minimum detectable effect, desired power, alpha, expected attrition, repeated-driver exposure, and marketplace clustering.

## Segment analysis

Zone and daypart estimates are shown for diagnosis and hypothesis generation. Do not select the winning segment only because its point estimate is largest. Check confidence intervals, multiple comparisons, sample size, cost per incremental trip, and practical constraints. Pre-register the main segments before a confirmatory experiment.

## Decision thresholds

`Expected gross incremental value per treated driver = estimated trip lift × assumed gross margin per incremental trip`

`Expected net value = expected gross incremental value − average incentive cost per treated driver`

`Scenario ROI = expected net value / average incentive cost per treated driver`

The `50,000 toman/trip` margin is a scenario parameter, not a verified Snapp finance metric. Always run sensitivity analysis and replace it with a Finance-approved contribution-margin definition before any commercial decision.

## Model-guided targeting

The T-learner fits one outcome model for control and one for treatment and estimates `uplift_hat(x) = mu1_hat(x) - mu0_hat(x)`. It scores a separate synthetic candidate pool. The top 20% are an evaluation cohort for the next campaign, not people who should automatically receive incentives. Use a randomized policy test (for example, randomize eligible candidates within score bands) to estimate incremental outcomes and economics. Compare against random targeting and business-as-usual.
