# Incentive Lab — Supply Incentive Optimization

[فارسی](README_FA.md) · [Full project brief (FA)](docs/project_description_fa.md) · [Interview guide (FA)](docs/interview_guide_fa.md) · [GitHub publishing guide (FA)](docs/publish_to_github_fa.md)

An end-to-end **Data Science portfolio project** for exploring how marketplace incentive campaigns can be evaluated and how candidate audiences can be prioritized with uplift-oriented modeling. It combines randomized A/B analysis, campaign economics, a T-learner, quality checks, offline monitoring, SQL reference queries, a FastAPI scoring service, and an interactive standalone dashboard.

> **Important:** This is an independent educational portfolio project inspired by a supply-incentive use case. It is **not affiliated with or endorsed by Snapp**, does not connect to Snapp systems, and uses only synthetic data. All metrics below are simulated examples, not company results or promises of savings.

## What the project demonstrates

- **Experimentation:** treatment-control estimates, Welch confidence intervals and tests, plus an adjusted OLS/HC3 robustness check.
- **Business economics:** incremental trips, incentive cost, scenario ROI, break-even margin, and sensitivity analysis.
- **Uplift-oriented modeling:** a T-learner with separate Random Forest outcome models for treatment and control, evaluated on a randomized holdout.
- **Decision support:** scoring a separate synthetic candidate pool and surfacing the top 20% for consideration in a future randomized test—not automatic incentive allocation.
- **Engineering practices:** reproducible pipeline, schema/quality checks, output artifacts, API validation, tests, Dockerfile, SQL Server reference scripts, and an offline drift snapshot.

## Illustrative results (synthetic data only)

| Item | Result from the bundled seed (`42`) | Correct interpretation |
|---|---:|---|
| Randomized experiment | 12,000 records: 5,899 treatment / 6,101 control | Generated test data, not production data |
| A/B trip effect (ATE) | **+1.996 trips** per assigned driver | 95% CI: **1.626 to 2.365** in this simulated experiment |
| Scenario ROI | **+16.5%** | Assumes 50,000 toman contribution margin per incremental trip; not a verified finance input |
| Independent scoring pool | 3,000 synthetic candidates; 600 in the top 20% | A shortlist for further randomized testing, not a production recommendation |
| Data quality checks | **PASS** | Checks the generated data and pipeline rules only |

### A key model limitation

In the holdout set, the top 20% predicted-uplift band had approximately **+4.47 predicted trips** but **+2.41 observed trips** (95% CI approximately **0.67 to 4.14**). This gap flags possible overprediction/calibration error. It does **not** establish that targeting by the model improves causal outcomes. A prospective randomized policy experiment, calibration work, and more robust validation are required before operational use.

## Dashboard and evidence

- [Open the standalone interactive dashboard HTML](snapp_incentive_dashboard_v3.html). To run it locally, use `python -m http.server 8080` from the repository root, then open `http://127.0.0.1:8080/snapp_incentive_dashboard_v3.html`.
- [A/B effect with confidence interval](project_outputs/figures/experiment_lift_ci.png)
- [Uplift-band validation](project_outputs/figures/uplift_decile_validation.png)
- [ROI sensitivity](project_outputs/figures/roi_sensitivity.png)
- [Cost per incremental trip by daypart](project_outputs/figures/daypart_cost_per_incremental_trip.png)
- [Persian validation report](docs/validation_report_fa.md)

## Quick start

Python 3.13 is the tested/recommended version for this package.

### Windows PowerShell

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.run_pipeline
python -m pytest -q
uvicorn api.app:app --reload
```

### macOS / Linux

```bash
python3.13 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m src.run_pipeline
python -m pytest -q
uvicorn api.app:app --reload
```

The full pipeline regenerates the synthetic experiment and candidate pool, runs data-quality checks and analysis, trains/scores the T-learner, creates charts and monitoring output, saves `artifacts/uplift_model.joblib`, and synchronizes the dashboard payload. Open `http://127.0.0.1:8000/docs` for interactive API documentation.

## API example

Check service/model status:

```bash
curl http://127.0.0.1:8000/health
```

Score one synthetic driver (the values below are illustrative):

```bash
curl -X POST "http://127.0.0.1:8000/score" \
  -H "Content-Type: application/json" \
  -d '{
    "driver_id": "DEMO-001",
    "zone": "central",
    "daypart": "evening",
    "avg_online_hours_4w": 20.0,
    "avg_trips_4w": 35.0,
    "cancellation_rate": 0.08,
    "demand_index": 1.0,
    "acceptance_rate": 0.82,
    "tenure_days": 180,
    "is_active_pre": 1
  }'
```

Endpoints: `GET /health`, `POST /score`, and `POST /score/batch`. Scores are model estimates and should not directly determine real incentive eligibility.

## Repository map

```text
api/                         FastAPI scoring service
artifacts/                   Bundled synthetic-data model artifact
data/raw/                    Synthetic experiment and candidate data
project_outputs/              Reproducible CSV/JSON outputs and figures
src/                         Data generation, analysis, modeling, QA, monitoring, orchestration
sql/                         Reference SQL Server schema and analytical queries
tests/                       Automated tests
docs/                         Data dictionary, design, lifecycle, Persian brief and interview guide
snapp_incentive_dashboard_v3.html  Standalone dashboard with embedded demo data
```

## Method and metric notes

- The unit of analysis is one synthetic driver per campaign assignment.
- The primary experiment estimate is the unadjusted randomized difference in mean `trips_next_week` between assigned treatment and control.
- The ROI calculation is a **scenario**, using an assumed 50,000 toman contribution margin per incremental trip. Replace it with an approved finance definition before any real decision.
- Post-treatment outcomes are not used as model input features for candidate scoring.
- The SQL scripts use SQL Server/T-SQL as reference examples; they have not been executed against a live database or mapped to a real warehouse.
- The monitoring artifact is an offline drift snapshot, not online production monitoring.
- The Dockerfile is supplied as a packaging example; no production deployment is included.

## Validation

The bundled version's automated test suite has **9 passing tests** in the prepared environment. The code and pipeline can be rerun locally; outputs may vary if the seed, dependency versions, or scenario assumptions are changed.

## Detailed documentation

- [Experiment design](docs/experiment_design.md)
- [Data dictionary](docs/data_dictionary.md)
- [System architecture](docs/architecture.md)
- [Model lifecycle and monitoring](docs/model_lifecycle.md)
- [Project brief in Persian (Markdown)](docs/project_description_fa.md)
- [Project brief in Persian (Word)](docs/project_description_fa.docx)
- [Interview guide in Persian](docs/interview_guide_fa.md)
- [GitHub publishing guide in Persian](docs/publish_to_github_fa.md)
- [SQL scripts and notes](sql/README.md)

## License

Distributed under the MIT License; see [LICENSE](LICENSE). This license applies to the project code and documentation authored for this repository, not to third-party trademarks.
